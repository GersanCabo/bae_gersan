CREATE DATABASE Jardineria;

USE Jardineria;

-- Aquí se deberia de añadir el script

SHOW DATABASES;

SHOW FULL TABLES FROM Jardineria;

SHOW COLUMNS FROM Jardineria.Clientes;

SHOW COLUMNS FROM Jardineria.Oficinas;
SHOW COLUMNS FROM Jardineria.Empleados;
SHOW COLUMNS FROM Jardineria.GamasProductos;
SHOW COLUMNS FROM Jardineria.Pedidos;
SHOW COLUMNS FROM Jardineria.Productos;
SHOW COLUMNS FROM Jardineria.DetallePedidos;
SHOW COLUMNS FROM Jardineria.Pagos;

SELECT * FROM Clientes;

SELECT NombreCliente, Telefono FROM Clientes;
